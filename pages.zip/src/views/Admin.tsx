import { useEffect, useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { useAuth } from "@/context/AuthContext";
import { useLang } from "@/context/LanguageContext";

const tabs = ["analytics", "users", "finance", "bitlabs", "adgem", "tasks", "vip", "announcements", "audit", "settings"];

export default function Admin() {
  const { token, user } = useAuth();
  const { t } = useLang();
  const [tab, setTab] = useState("analytics");
  const [analytics, setAnalytics] = useState<any>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [bitlabs, setBitlabs] = useState<any[]>([]);
  const [adgem, setAdgem] = useState<any[]>([]);
  const [bitlabsLogs, setBitlabsLogs] = useState<any[]>([]);
  const [adgemLogs, setAdgemLogs] = useState<any[]>([]);
  const [tasks, setTasks] = useState<any[]>([]);
  const [vipLevels, setVipLevels] = useState<any[]>([]);
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [activityLogs, setActivityLogs] = useState<any[]>([]);
  const [fraudLogs, setFraudLogs] = useState<any[]>([]);
  const [settings, setSettings] = useState<any>(null);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState("");
  const [newTask, setNewTask] = useState({ title: "", description: "", reward: 0.1, type: "general" });
  const [newAnnouncement, setNewAnnouncement] = useState({ title: "", body: "", audience: "all", locale: "all" });
  const [newVip, setNewVip] = useState({ level: 6, name: "VIP 6", price: 0, multiplier: 1, dailyLimit: 0, benefits: "" });

  const h = { Authorization: `Bearer ${token}`, "Content-Type": "application/json" };

  async function loadAdminData() {
    if (!token || !user?.isAdmin) return;
    const [
      analyticsData,
      usersData,
      transactionsData,
      withdrawalsData,
      bitlabsData,
      adgemData,
      bitlabsWebhookData,
      adgemWebhookData,
      tasksData,
      vipData,
      announcementsData,
      activityData,
      fraudData,
      settingsData,
    ] = await Promise.all([
      fetch("/api/admin/analytics", { headers: h }).then(r => r.json()),
      fetch(`/api/admin/users${search ? `?q=${encodeURIComponent(search)}` : ""}`, { headers: h }).then(r => r.json()),
      fetch("/api/admin/transactions", { headers: h }).then(r => r.json()),
      fetch("/api/admin/withdrawals", { headers: h }).then(r => r.json()),
      fetch("/api/admin/providers/bitlabs/conversions", { headers: h }).then(r => r.json()),
      fetch("/api/admin/providers/adgem/conversions", { headers: h }).then(r => r.json()),
      fetch("/api/admin/providers/bitlabs/postbacks", { headers: h }).then(r => r.json()),
      fetch("/api/admin/providers/adgem/postbacks", { headers: h }).then(r => r.json()),
      fetch("/api/admin/tasks", { headers: h }).then(r => r.json()),
      fetch("/api/admin/vip-levels", { headers: h }).then(r => r.json()),
      fetch("/api/admin/announcements", { headers: h }).then(r => r.json()),
      fetch("/api/admin/logs/activity", { headers: h }).then(r => r.json()),
      fetch("/api/admin/logs/fraud", { headers: h }).then(r => r.json()),
      fetch("/api/admin/settings", { headers: h }).then(r => r.json()),
    ]);

    setAnalytics(analyticsData);
    setUsers(usersData);
    setTransactions(transactionsData);
    setWithdrawals(withdrawalsData);
    setBitlabs(bitlabsData);
    setAdgem(adgemData);
    setBitlabsLogs(bitlabsWebhookData);
    setAdgemLogs(adgemWebhookData);
    setTasks(tasksData);
    setVipLevels(vipData);
    setAnnouncements(announcementsData);
    setActivityLogs(activityData);
    setFraudLogs(fraudData);
    setSettings(settingsData);
  }

  useEffect(() => {
    loadAdminData().catch(() => {});
  }, [token, user?.isAdmin, search]);

  async function patchUser(userId: number, updates: any) {
    await fetch(`/api/admin/users/${userId}`, { method: "PATCH", headers: h, body: JSON.stringify(updates) });
    await loadAdminData();
  }

  async function patchWithdrawal(id: number, status: string) {
    await fetch(`/api/admin/withdrawals/${id}`, { method: "PATCH", headers: h, body: JSON.stringify({ status }) });
    await loadAdminData();
  }

  async function patchVipLevel(id: number, updates: any) {
    await fetch(`/api/admin/vip-levels/${id}`, { method: "PATCH", headers: h, body: JSON.stringify(updates) });
    await loadAdminData();
  }

  async function createVipLevel() {
    await fetch("/api/admin/vip-levels", {
      method: "POST",
      headers: h,
      body: JSON.stringify({
        level: newVip.level,
        name: newVip.name,
        price: newVip.price,
        multiplier: newVip.multiplier,
        dailyLimit: newVip.dailyLimit,
        benefits: newVip.benefits.split("\n").filter(Boolean),
      }),
    });
    setNewVip({ level: newVip.level + 1, name: "VIP New", price: 0, multiplier: 1, dailyLimit: 0, benefits: "" });
    await loadAdminData();
  }

  async function createTask(e: React.FormEvent) {
    e.preventDefault();
    await fetch("/api/admin/tasks", { method: "POST", headers: h, body: JSON.stringify(newTask) });
    setNewTask({ title: "", description: "", reward: 0.1, type: "general" });
    await loadAdminData();
  }

  async function deleteTask(id: number) {
    await fetch(`/api/admin/tasks/${id}`, { method: "DELETE", headers: h });
    await loadAdminData();
  }

  async function saveAnnouncement(e: React.FormEvent) {
    e.preventDefault();
    await fetch("/api/admin/announcements", { method: "POST", headers: h, body: JSON.stringify(newAnnouncement) });
    setNewAnnouncement({ title: "", body: "", audience: "all", locale: "all" });
    await loadAdminData();
  }

  async function saveSettings(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    await fetch("/api/admin/settings", { method: "PATCH", headers: h, body: JSON.stringify(settings) });
    await loadAdminData();
    setSaving(false);
  }

  function renderMetric(label: string, value: string | number) {
    return (
      <div key={label} className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm">
        <div className="text-2xl font-bold text-gray-900 dark:text-white">{value}</div>
        <div className="text-sm text-gray-500 mt-1">{label}</div>
      </div>
    );
  }

  function renderRows(rows: any[], columns: Array<{ key: string; label: string; render?: (row: any) => any }>) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-gray-500 border-b border-gray-100 dark:border-gray-700">
              {columns.map((column) => <th key={column.key} className="px-4 py-3">{column.label}</th>)}
            </tr>
          </thead>
          <tbody>
            {rows.map((row, index) => (
              <tr key={row.id ?? `${index}-${row.transactionId ?? row.title ?? "row"}`} className="border-b border-gray-50 dark:border-gray-700 align-top">
                {columns.map((column) => <td key={column.key} className="px-4 py-3 text-gray-700 dark:text-gray-200">{column.render ? column.render(row) : row[column.key]}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  if (!user?.isAdmin) return <DashboardLayout><p className="text-red-500">Access denied</p></DashboardLayout>;

  return (
    <DashboardLayout>
      <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">{t("admin")}</h1>

      <div className="flex gap-2 mb-6 flex-wrap">
        {tabs.map((item) => (
          <button key={item} onClick={() => setTab(item)} className={`px-4 py-2 rounded-lg text-sm font-medium ${tab === item ? "bg-blue-600 text-white" : "bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300"}`}>
            {item}
          </button>
        ))}
      </div>

      {tab === "analytics" && analytics && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              ["Daily Active Users", analytics.activeUsers],
              ["Revenue Today", `$${Number(analytics.revenueToday ?? 0).toFixed(2)}`],
              ["Revenue This Week", `$${Number(analytics.revenueThisWeek ?? 0).toFixed(2)}`],
              ["Revenue This Month", `$${Number(analytics.revenueThisMonth ?? 0).toFixed(2)}`],
              ["BitLabs Revenue", `$${Number(analytics.bitlabsRevenue ?? 0).toFixed(2)}`],
              ["AdGem Revenue", `$${Number(analytics.adgemRevenue ?? 0).toFixed(2)}`],
              ["TADS Revenue", `$${Number(analytics.tadsRevenue ?? 0).toFixed(2)}`],
              ["Withdrawals", `$${Number(analytics.totalWithdrawals ?? 0).toFixed(2)}`],
              ["User Growth", analytics.totalUsers],
              ["Fraud Events", analytics.fraudEvents],
              ["BitLabs Conversions", analytics.bitlabsConversions],
              ["AdGem Conversions", analytics.adgemConversions],
            ].map(([label, value]) => renderMetric(String(label), value as any))}
          </div>
          <div className="grid lg:grid-cols-2 gap-6">
            <div className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm">
              <h2 className="font-semibold text-gray-900 dark:text-white mb-4">Top Users</h2>
              <div className="space-y-3">
                {(analytics.topUsers ?? []).map((item: any) => (
                  <div key={item.id} className="flex items-center justify-between">
                    <div>
                      <div className="font-medium text-gray-900 dark:text-white">{item.name}</div>
                      <div className="text-sm text-gray-500">{item.telegramId}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold text-green-600">${Number(item.rewardTotal).toFixed(2)}</div>
                      <div className="text-xs text-gray-500">rev ${Number(item.revenueTotal).toFixed(2)}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm">
              <h2 className="font-semibold text-gray-900 dark:text-white mb-4">Chart Snapshots</h2>
              <div className="space-y-4">
                {Object.entries(analytics.charts ?? {}).map(([key, values]: [string, any]) => (
                  <div key={key}>
                    <div className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{key}</div>
                    <div className="flex gap-2 items-end h-28">
                      {values.map((point: any) => (
                        <div key={`${key}-${point.day}`} className="flex-1">
                          <div className="rounded-t bg-blue-500/80" style={{ height: `${Math.max(8, Number(point.value || 0) * 10)}px` }} />
                          <div className="text-[10px] text-gray-400 mt-1 truncate">{point.day.slice(5)}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {tab === "users" && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm">
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search users"
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white outline-none"
            />
          </div>
          {renderRows(users, [
            { key: "name", label: "Name" },
            { key: "telegramId", label: "Telegram ID" },
            { key: "username", label: "Username" },
            { key: "balance", label: "Balance", render: (row) => `$${Number(row.balance).toFixed(2)}` },
            { key: "vipLevel", label: "VIP" },
            { key: "status", label: "Status", render: (row) => row.isBanned ? "Banned" : "Active" },
            {
              key: "actions",
              label: "Actions",
              render: (row) => (
                <div className="flex gap-2 flex-wrap">
                  <button onClick={() => patchUser(row.id, { isBanned: !row.isBanned })} className="px-2 py-1 rounded text-xs bg-blue-100 text-blue-700">{row.isBanned ? "Unban" : "Ban"}</button>
                  <button onClick={() => patchUser(row.id, { balanceAdjustment: 1 })} className="px-2 py-1 rounded text-xs bg-green-100 text-green-700">+1</button>
                  <button onClick={() => patchUser(row.id, { balanceAdjustment: -1 })} className="px-2 py-1 rounded text-xs bg-red-100 text-red-700">-1</button>
                </div>
              ),
            },
          ])}
        </div>
      )}

      {tab === "finance" && (
        <div className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            {renderRows(withdrawals, [
              { key: "userName", label: "User" },
              { key: "method", label: "Method" },
              { key: "amount", label: "Amount", render: (row) => `$${Number(row.amount).toFixed(2)}` },
              { key: "status", label: "Status" },
              {
                key: "actions",
                label: "Actions",
                render: (row) => (
                  <div className="flex gap-2">
                    <button onClick={() => patchWithdrawal(row.id, "approved")} className="px-2 py-1 rounded text-xs bg-green-100 text-green-700">Approve</button>
                    <button onClick={() => patchWithdrawal(row.id, "rejected")} className="px-2 py-1 rounded text-xs bg-red-100 text-red-700">Reject</button>
                  </div>
                ),
              },
            ])}
            {renderRows(transactions.slice(0, 40), [
              { key: "userName", label: "User" },
              { key: "type", label: "Type" },
              { key: "source", label: "Source" },
              { key: "amount", label: "Amount", render: (row) => `$${Number(row.amount).toFixed(2)}` },
              { key: "createdAt", label: "Date", render: (row) => new Date(row.createdAt).toLocaleString() },
            ])}
          </div>
        </div>
      )}

      {tab === "bitlabs" && (
        <div className="space-y-6">
          <div className="grid md:grid-cols-4 gap-4">
            {renderMetric("Total Revenue", `$${Number(analytics?.bitlabsRevenue ?? 0).toFixed(2)}`)}
            {renderMetric("Total Conversions", analytics?.bitlabsConversions ?? 0)}
            {renderMetric("Revenue Today", `$${Number(analytics?.revenueToday ?? 0).toFixed(2)}`)}
            {renderMetric("Top Users", (analytics?.topUsers ?? []).length)}
          </div>
          {renderRows(bitlabs.slice(0, 100), [
            { key: "userName", label: "User" },
            { key: "transactionId", label: "Transaction" },
            { key: "title", label: "Title" },
            { key: "rewardAmount", label: "Reward", render: (row) => `$${Number(row.rewardAmount).toFixed(2)}` },
            { key: "revenueUsd", label: "Revenue", render: (row) => `$${Number(row.revenueUsd).toFixed(2)}` },
            { key: "createdAt", label: "Date", render: (row) => new Date(row.createdAt).toLocaleString() },
          ])}
          {renderRows(bitlabsLogs.slice(0, 80), [
            { key: "status", label: "Status" },
            { key: "signatureValid", label: "Signature", render: (row) => row.signatureValid ? "valid" : "invalid" },
            { key: "referenceId", label: "Reference" },
            { key: "createdAt", label: "Date", render: (row) => new Date(row.createdAt).toLocaleString() },
          ])}
        </div>
      )}

      {tab === "adgem" && (
        <div className="space-y-6">
          <div className="grid md:grid-cols-4 gap-4">
            {renderMetric("Total Revenue", `$${Number(analytics?.adgemRevenue ?? 0).toFixed(2)}`)}
            {renderMetric("Total Conversions", analytics?.adgemConversions ?? 0)}
            {renderMetric("Revenue Today", `$${Number(analytics?.revenueToday ?? 0).toFixed(2)}`)}
            {renderMetric("Top Users", (analytics?.topUsers ?? []).length)}
          </div>
          {renderRows(adgem.slice(0, 100), [
            { key: "userName", label: "User" },
            { key: "transactionId", label: "Transaction" },
            { key: "title", label: "Goal / Offer" },
            { key: "conversionType", label: "Type" },
            { key: "rewardAmount", label: "Reward", render: (row) => `$${Number(row.rewardAmount).toFixed(2)}` },
            { key: "revenueUsd", label: "Revenue", render: (row) => `$${Number(row.revenueUsd).toFixed(2)}` },
          ])}
          {renderRows(adgemLogs.slice(0, 80), [
            { key: "status", label: "Status" },
            { key: "signatureValid", label: "Signature", render: (row) => row.signatureValid ? "valid" : "invalid" },
            { key: "referenceId", label: "Reference" },
            { key: "createdAt", label: "Date", render: (row) => new Date(row.createdAt).toLocaleString() },
          ])}
        </div>
      )}

      {tab === "tasks" && (
        <div className="space-y-6">
          <form onSubmit={createTask} className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm grid md:grid-cols-4 gap-3">
            <input value={newTask.title} onChange={(e) => setNewTask({ ...newTask, title: e.target.value })} placeholder="Title" className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700" />
            <input value={newTask.description} onChange={(e) => setNewTask({ ...newTask, description: e.target.value })} placeholder="Description" className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700" />
            <input type="number" step="0.0001" value={newTask.reward} onChange={(e) => setNewTask({ ...newTask, reward: Number(e.target.value) })} className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700" />
            <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-lg">Create Task</button>
          </form>
          {renderRows(tasks, [
            { key: "title", label: "Title" },
            { key: "description", label: "Description" },
            { key: "type", label: "Type" },
            { key: "reward", label: "Reward", render: (row) => `$${Number(row.reward).toFixed(4)}` },
            { key: "isActive", label: "Status", render: (row) => row.isActive ? "Active" : "Disabled" },
            {
              key: "actions",
              label: "Actions",
              render: (row) => (
                <div className="flex gap-2">
                  <button onClick={() => deleteTask(row.id)} className="px-2 py-1 rounded text-xs bg-red-100 text-red-700">Delete</button>
                </div>
              ),
            },
          ])}
        </div>
      )}

      {tab === "vip" && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm grid md:grid-cols-5 gap-3">
            <input type="number" value={newVip.level} onChange={(e) => setNewVip({ ...newVip, level: Number(e.target.value) })} className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700" />
            <input value={newVip.name} onChange={(e) => setNewVip({ ...newVip, name: e.target.value })} className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700" />
            <input type="number" value={newVip.price} onChange={(e) => setNewVip({ ...newVip, price: Number(e.target.value) })} className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700" />
            <input type="number" step="0.01" value={newVip.multiplier} onChange={(e) => setNewVip({ ...newVip, multiplier: Number(e.target.value) })} className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700" />
            <button type="button" onClick={createVipLevel} className="px-4 py-2 bg-blue-600 text-white rounded-lg">Create VIP</button>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            {vipLevels.map((level) => (
              <div key={level.id} className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm space-y-3">
                <div className="font-semibold text-gray-900 dark:text-white">{level.name}</div>
                <div className="grid grid-cols-3 gap-3">
                  <input type="number" value={level.price} onChange={(e) => setVipLevels(vipLevels.map((item) => item.id === level.id ? { ...item, price: Number(e.target.value) } : item))} className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700" />
                  <input type="number" step="0.01" value={level.multiplier} onChange={(e) => setVipLevels(vipLevels.map((item) => item.id === level.id ? { ...item, multiplier: Number(e.target.value) } : item))} className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700" />
                  <input type="number" value={level.dailyLimit} onChange={(e) => setVipLevels(vipLevels.map((item) => item.id === level.id ? { ...item, dailyLimit: Number(e.target.value) } : item))} className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700" />
                </div>
                <textarea value={(level.benefits || []).join("\n")} onChange={(e) => setVipLevels(vipLevels.map((item) => item.id === level.id ? { ...item, benefits: e.target.value.split("\n").filter(Boolean) } : item))} className="w-full min-h-24 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700" />
                <div className="flex gap-2">
                  <button onClick={() => patchVipLevel(level.id, level)} className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm">Save</button>
                  <button onClick={() => patchVipLevel(level.id, { isActive: !level.isActive })} className="px-4 py-2 bg-gray-200 dark:bg-gray-700 rounded-lg text-sm">{level.isActive ? "Disable" : "Enable"}</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === "announcements" && (
        <div className="space-y-6">
          <form onSubmit={saveAnnouncement} className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm space-y-3">
            <input value={newAnnouncement.title} onChange={(e) => setNewAnnouncement({ ...newAnnouncement, title: e.target.value })} placeholder="Title" className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700" />
            <textarea value={newAnnouncement.body} onChange={(e) => setNewAnnouncement({ ...newAnnouncement, body: e.target.value })} placeholder="Broadcast message" className="w-full min-h-28 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700" />
            <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-lg">Broadcast</button>
          </form>
          {renderRows(announcements, [
            { key: "title", label: "Title" },
            { key: "body", label: "Message" },
            { key: "audience", label: "Audience" },
            { key: "locale", label: "Locale" },
            { key: "createdAt", label: "Date", render: (row) => new Date(row.createdAt).toLocaleString() },
          ])}
        </div>
      )}

      {tab === "audit" && (
        <div className="space-y-6">
          {renderRows(activityLogs.slice(0, 100), [
            { key: "action", label: "Action" },
            { key: "entityType", label: "Entity" },
            { key: "entityId", label: "Reference" },
            { key: "userId", label: "User" },
            { key: "createdAt", label: "Date", render: (row) => new Date(row.createdAt).toLocaleString() },
          ])}
          {renderRows(fraudLogs.slice(0, 80), [
            { key: "provider", label: "Provider" },
            { key: "status", label: "Reason" },
            { key: "referenceId", label: "Reference" },
            { key: "createdAt", label: "Date", render: (row) => new Date(row.createdAt).toLocaleString() },
          ])}
        </div>
      )}

      {tab === "settings" && settings && (
        <form onSubmit={saveSettings} className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm space-y-6">
          <div className="grid md:grid-cols-2 gap-4">
            {[
              ["brandingName", "Platform Branding"],
              ["telegramBotToken", "Telegram Bot Token"],
              ["telegramMiniAppUrl", "Telegram Mini App URL"],
              ["tadsAppId", "TADS App ID"],
              ["bitlabsApiKey", "BitLabs API Key"],
              ["bitlabsAppId", "BitLabs App ID"],
              ["bitlabsSecretKey", "BitLabs Secret Key"],
              ["adgemPublisherId", "AdGem Publisher ID"],
              ["adgemApiKey", "AdGem API Key"],
              ["adgemWallId", "AdGem Wall ID"],
              ["adgemPostbackSecret", "AdGem Postback Secret"],
              ["withdrawalMinimum", "Withdrawal Minimum"],
              ["referralSignupReward", "Referral Reward"],
              ["referralCommissionRate", "Referral Percentage"],
            ].map(([key, label]) => (
              <div key={key}>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{label}</label>
                <input value={settings[key] ?? ""} onChange={(e) => setSettings({ ...settings, [key]: e.target.value })} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white outline-none" />
              </div>
            ))}
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              {[
                ["bitlabsEnabled", "Enable BitLabs"],
                ["bitlabsMaintenanceMode", "BitLabs Maintenance"],
                ["adgemEnabled", "Enable AdGem"],
                ["taskBitlabsEnabled", "Enable BitLabs Tasks"],
                ["taskAdgemEnabled", "Enable AdGem Tasks"],
                ["dailyBonusEnabled", "Enable Daily Bonus"],
                ["referralTasksEnabled", "Enable Referral Tasks"],
                ["tadsEnabled", "Enable TADS"],
                ["withdrawalsEnabled", "Enable Withdrawals"],
              ].map(([key, label]) => (
                <label key={key} className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-300">
                  <input type="checkbox" checked={Boolean(settings[key])} onChange={(e) => setSettings({ ...settings, [key]: e.target.checked })} />
                  {label}
                </label>
              ))}
            </div>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">BitLabs Postback URL</label>
                <input value={settings.bitlabsPostbackUrl ?? ""} readOnly className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700/60 text-gray-700 dark:text-gray-200 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">AdGem Postback URL</label>
                <input value={settings.adgemPostbackUrl ?? ""} readOnly className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700/60 text-gray-700 dark:text-gray-200 outline-none" />
              </div>
            </div>
          </div>
          <button type="submit" disabled={saving} className="w-full py-2.5 bg-blue-600 text-white rounded-lg font-medium disabled:opacity-60">
            {saving ? t("loading") : t("saveSettings")}
          </button>
        </form>
      )}
    </DashboardLayout>
  );
}
